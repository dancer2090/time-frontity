const serve = require("./node_modules/@frontity/core/dist/src/scripts/serve").default;

serve({
  isHttps: false,
  port: 7800
});