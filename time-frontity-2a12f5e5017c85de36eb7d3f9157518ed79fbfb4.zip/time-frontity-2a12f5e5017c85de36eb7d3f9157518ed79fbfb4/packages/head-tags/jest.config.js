const rootConfig = require("../../jest.config.js");
module.exports = rootConfig;
