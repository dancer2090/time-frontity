import SvgSprite from './SvgSprite';

export default SvgSprite;
