import PersonCard from './PersonCard';

export default PersonCard;
