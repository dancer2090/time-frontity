import Translator from './Translator';

export default Translator;
