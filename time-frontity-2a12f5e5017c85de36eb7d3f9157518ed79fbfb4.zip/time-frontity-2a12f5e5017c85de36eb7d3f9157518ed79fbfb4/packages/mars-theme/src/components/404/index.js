import Page404 from './Page404';

export default Page404;
