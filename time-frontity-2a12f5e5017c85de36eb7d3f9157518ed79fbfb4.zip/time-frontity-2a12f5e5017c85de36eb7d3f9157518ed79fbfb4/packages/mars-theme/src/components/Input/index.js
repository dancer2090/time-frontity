import Input from './Input';

export default Input;
