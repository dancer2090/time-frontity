import NewsCardPreview from './NewsCardPreview';

export default NewsCardPreview;
