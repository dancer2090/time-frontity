import ModalComponent from './Modal';

export default ModalComponent;
