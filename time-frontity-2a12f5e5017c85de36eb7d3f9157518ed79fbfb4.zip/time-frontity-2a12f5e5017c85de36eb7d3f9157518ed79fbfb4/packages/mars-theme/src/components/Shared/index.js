import Shared from './Shared';

export default Shared;
