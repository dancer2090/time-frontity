import SubscribeNews from './SubscribeNews';

export default SubscribeNews;
