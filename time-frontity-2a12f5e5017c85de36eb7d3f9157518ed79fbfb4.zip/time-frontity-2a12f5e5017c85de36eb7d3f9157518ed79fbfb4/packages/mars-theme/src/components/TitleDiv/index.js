import TitleDiv from './TitleDiv';

export default TitleDiv;
