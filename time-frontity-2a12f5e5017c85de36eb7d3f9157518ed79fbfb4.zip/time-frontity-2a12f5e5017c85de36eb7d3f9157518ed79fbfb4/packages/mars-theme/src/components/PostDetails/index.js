import PostDetails from './PostDetails';

export default PostDetails;
