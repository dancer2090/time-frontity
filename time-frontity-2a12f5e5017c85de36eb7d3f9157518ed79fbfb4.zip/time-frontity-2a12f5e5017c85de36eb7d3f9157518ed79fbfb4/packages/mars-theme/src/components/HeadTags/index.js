import HeadTags from './HeadTags';

export default HeadTags;
