import Recaptcha from './Recaptcha';

export default Recaptcha;
