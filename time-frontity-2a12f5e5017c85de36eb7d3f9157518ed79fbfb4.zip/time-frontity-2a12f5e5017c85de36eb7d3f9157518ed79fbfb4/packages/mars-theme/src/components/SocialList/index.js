import SocialList from './SocialList';

export default SocialList;
