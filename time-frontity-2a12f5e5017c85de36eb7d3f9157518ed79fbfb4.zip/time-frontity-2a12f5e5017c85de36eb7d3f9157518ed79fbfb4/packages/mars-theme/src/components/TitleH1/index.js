import TitleH1 from './TitleH1';

export default TitleH1;
