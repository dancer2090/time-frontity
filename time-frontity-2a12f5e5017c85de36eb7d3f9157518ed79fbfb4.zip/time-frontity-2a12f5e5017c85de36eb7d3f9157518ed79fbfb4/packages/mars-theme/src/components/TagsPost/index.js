import TabsPost from './TabsPost';

export default TabsPost;
