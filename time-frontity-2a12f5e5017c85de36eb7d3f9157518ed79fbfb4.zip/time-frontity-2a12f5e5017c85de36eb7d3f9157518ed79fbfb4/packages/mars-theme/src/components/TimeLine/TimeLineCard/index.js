import TimeLineCard from './TimeLineCard';

export default TimeLineCard;
