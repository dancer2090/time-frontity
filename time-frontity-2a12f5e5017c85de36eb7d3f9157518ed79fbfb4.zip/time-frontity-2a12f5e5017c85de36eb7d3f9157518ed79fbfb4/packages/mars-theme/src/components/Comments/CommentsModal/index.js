import CommentsModal from './CommentsModal';

export default CommentsModal;
