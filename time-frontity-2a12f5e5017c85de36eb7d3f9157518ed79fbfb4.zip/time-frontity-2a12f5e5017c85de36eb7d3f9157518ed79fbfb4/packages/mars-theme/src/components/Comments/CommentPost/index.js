import CommentPost from './CommentPost';

export default CommentPost;
