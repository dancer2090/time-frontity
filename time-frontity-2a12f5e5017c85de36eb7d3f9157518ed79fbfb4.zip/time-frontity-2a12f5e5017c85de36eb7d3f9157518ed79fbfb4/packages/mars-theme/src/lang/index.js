import uk from './ua';
import ru from './ru';

export default {
  uk,
  ru,
};
