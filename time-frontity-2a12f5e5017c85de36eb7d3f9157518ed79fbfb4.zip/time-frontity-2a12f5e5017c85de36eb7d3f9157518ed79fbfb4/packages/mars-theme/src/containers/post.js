import React from 'react';
import PostContent from './Post/Content';

const Post = ({ scrollRef = null }) => <PostContent scrollRef={scrollRef} />;

export default Post;
