import MediaCenterTemplate from './MediaCenterTemplate';

export default MediaCenterTemplate;
