import PhotoListTemplate from './PhotoListTemplate';

export default PhotoListTemplate;
