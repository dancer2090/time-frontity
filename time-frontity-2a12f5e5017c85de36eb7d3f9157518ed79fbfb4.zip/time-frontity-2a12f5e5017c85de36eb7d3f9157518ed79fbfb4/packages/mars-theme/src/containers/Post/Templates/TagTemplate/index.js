import TagTemplate from './TagTemplate';

export default TagTemplate;
