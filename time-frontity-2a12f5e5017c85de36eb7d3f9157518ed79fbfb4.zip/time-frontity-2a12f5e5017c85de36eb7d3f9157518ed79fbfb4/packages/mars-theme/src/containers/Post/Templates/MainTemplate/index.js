import MainTemplate from './MainTemplate';

export default MainTemplate;
