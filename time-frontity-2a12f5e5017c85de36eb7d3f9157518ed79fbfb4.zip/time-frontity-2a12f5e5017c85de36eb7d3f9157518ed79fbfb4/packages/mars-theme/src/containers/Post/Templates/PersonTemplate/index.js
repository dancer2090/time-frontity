import PersonTemplate from './PersonTemplate';

export default PersonTemplate;
