import ContactsTemplate from './ContactsTemplate';

export default ContactsTemplate;
