import ResultSearchTemplate from './ResultSearchTemplate';

export default ResultSearchTemplate;
