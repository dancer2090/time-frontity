import PublicationHeader from './PublicationHeader';

export default PublicationHeader;
