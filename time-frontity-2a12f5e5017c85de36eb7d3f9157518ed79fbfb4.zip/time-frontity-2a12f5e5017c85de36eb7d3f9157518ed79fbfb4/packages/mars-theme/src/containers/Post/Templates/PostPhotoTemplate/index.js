import PostPhotoTemplate from './PostPhotoTemplate';

export default PostPhotoTemplate;
