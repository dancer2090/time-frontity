import SpecialThemeTemplate from './SpecialThemeTemplate';

export default SpecialThemeTemplate;
