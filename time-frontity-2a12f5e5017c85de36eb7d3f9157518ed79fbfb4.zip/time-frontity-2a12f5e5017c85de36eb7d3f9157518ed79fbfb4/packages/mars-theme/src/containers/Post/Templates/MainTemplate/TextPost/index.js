import TextPost from './TextPost';

export default TextPost;
