import HeaderNews from './HeaderNews';

export default HeaderNews;
