import VideoTemplate from './VideoTemplate';

export default VideoTemplate;
