import PostTemplate from './PostTemplate';

export default PostTemplate;
