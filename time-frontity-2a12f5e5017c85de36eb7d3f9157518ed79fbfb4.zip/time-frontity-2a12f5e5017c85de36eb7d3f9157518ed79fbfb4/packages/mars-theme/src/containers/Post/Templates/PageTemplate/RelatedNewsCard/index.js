import RelatedNewsCard from './RelatedNewsCard';

export default RelatedNewsCard;
