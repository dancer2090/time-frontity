import AuthorsTemplate from './AuthorsTemplate';

export default AuthorsTemplate;
