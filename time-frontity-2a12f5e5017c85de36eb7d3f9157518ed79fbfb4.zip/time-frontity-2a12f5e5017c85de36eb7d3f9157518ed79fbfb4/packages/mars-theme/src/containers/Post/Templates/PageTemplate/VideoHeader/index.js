import VideoHeader from './VideoHeader';

export default VideoHeader;
