## Overview
Example: This PR adds the home page section...

## Testing instructions
Describe the testing steps.

## Trello task
---

## Checklist before submitting
- [ ] Title: Don't forget to make it clear for everyone, even for people that don't know about the feature/bug.
- [ ] Code: Use eslint and prettier 
